fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'lisix-blips'
author 'Lisix'
description 'In-game blip manager with a modern UI (HR / EN)'
version '1.0.0'

shared_scripts {
    'config.lua',
    'locales/*.lua',
    'shared.lua',
}

server_script 'server/main.lua'
client_script 'client/main.lua'

ui_page 'html/index.html'
files {
    'html/index.html',
    'html/style.css',
    'html/app.js',
    'html/sprites.js',
    'html/colors.js',
}
