-- lisix-blips | client
local handles = {}   -- [id] = blip handle
local open = false
local pending, reqId = {}, 0

----------------------------------------------------------------
-- map blips
----------------------------------------------------------------
local function clear()
    for _, h in pairs(handles) do if DoesBlipExist(h) then RemoveBlip(h) end end
    handles = {}
end

local function create(b)
    local h = AddBlipForCoord(b.x + 0.0, b.y + 0.0, b.z + 0.0)
    SetBlipSprite(h, b.sprite)
    SetBlipColour(h, b.color)
    SetBlipScale(h, b.scale + 0.0)
    SetBlipDisplay(h, 4)
    SetBlipAsShortRange(h, b.shortRange == true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(b.name)
    EndTextCommandSetBlipName(h)
    handles[b.id] = h
end

RegisterNetEvent('lisix-blips:sync', function(list)
    clear()
    for _, b in ipairs(list or {}) do create(b) end
end)

CreateThread(function()
    while not NetworkIsSessionStarted() do Wait(500) end
    TriggerServerEvent('lisix-blips:request')
end)

AddEventHandler('onResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    clear()
    if open then SetNuiFocus(false, false) end
end)

----------------------------------------------------------------
-- server calls
----------------------------------------------------------------
local function call(event, ...)
    reqId = reqId + 1
    local id = reqId
    local p = promise.new()
    pending[id] = p
    TriggerServerEvent(event, id, ...)
    SetTimeout(10000, function()
        if pending[id] then pending[id] = nil; p:resolve({ ok = false }) end
    end)
    return Citizen.Await(p)
end

RegisterNetEvent('lisix-blips:result', function(id, ok, msg, list, now)
    local p = pending[id]
    if not p then return end
    pending[id] = nil
    p:resolve({ ok = ok, msg = msg, blips = list, now = now })
end)

----------------------------------------------------------------
-- notifications (lisix-notify, ox_lib or GTA feed)
----------------------------------------------------------------
local function notify(msg, kind)
    if GetResourceState('lisix-notify') == 'started' then
        TriggerEvent('lisix-notify:notify', kind == 'error' and 'error' or 'success', msg, 5000, 'Blips')
    elseif GetResourceState('ox_lib') == 'started' then
        TriggerEvent('ox_lib:notify', { description = msg, type = kind == 'error' and 'error' or 'success' })
    else
        BeginTextCommandThefeedPost('STRING')
        AddTextComponentSubstringPlayerName(msg)
        EndTextCommandThefeedPostTicker(false, false)
    end
end
RegisterNetEvent('lisix-blips:notify', notify)

----------------------------------------------------------------
-- UI
----------------------------------------------------------------
RegisterNetEvent('lisix-blips:open', function(data)
    if open then return end
    open = true
    SetNuiFocus(true, true)
    SendNUIMessage({ action = 'open', data = data })
end)

local function close()
    if not open then return end
    open = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
end

RegisterNUICallback('close', function(_, cb) close() cb(1) end)

RegisterNUICallback('save', function(data, cb)
    cb(call('lisix-blips:save', data))
end)

RegisterNUICallback('delete', function(data, cb)
    cb(call('lisix-blips:delete', data and data.id))
end)

RegisterNUICallback('refresh', function(_, cb)
    cb(call('lisix-blips:list'))
end)

RegisterNUICallback('position', function(_, cb)
    local c = GetEntityCoords(PlayerPedId())
    cb({ x = c.x, y = c.y, z = c.z })
end)

RegisterNUICallback('waypoint', function(data, cb)
    SetNewWaypoint(data.x + 0.0, data.y + 0.0)
    cb(1)
end)

RegisterNUICallback('teleport', function(data, cb)
    cb(1)
    close()
    local ped = PlayerPedId()
    local x, y, z = data.x + 0.0, data.y + 0.0, data.z + 0.0
    DoScreenFadeOut(250)
    while not IsScreenFadedOut() do Wait(0) end
    RequestCollisionAtCoord(x, y, z)
    SetEntityCoordsNoOffset(ped, x, y, z + 1.0, false, false, false)
    local t = GetGameTimer() + 3000
    while not HasCollisionLoadedAroundEntity(ped) and GetGameTimer() < t do Wait(0) end
    local found, gz = GetGroundZFor_3dCoord(x, y, z + 50.0, false)
    if found then SetEntityCoordsNoOffset(ped, x, y, gz + 0.5, false, false, false) end
    DoScreenFadeIn(250)
end)
