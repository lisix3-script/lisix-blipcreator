Config = {}

-- 'hr' ili 'en' / 'hr' or 'en'
Config.Locale = 'hr'

-- Komanda za otvaranje / Command to open the manager
Config.Command = 'blips'

-- Tko smije upravljati blipovima / Who can manage blips
-- 1) ACE: add_ace group.admin lisixblips.admin allow
-- 2) ESX / QBCore grupe (ako framework postoji) / framework groups (if a framework is running)
Config.Permission = {
    Ace = 'lisixblips.admin',
    Groups = { 'admin', 'superadmin', 'god' },
}

-- 'auto' = oxmysql ako je pokrenut, inače data/blips.json
-- 'auto' = oxmysql when it is running, otherwise data/blips.json
-- 'mysql' | 'json'
Config.Storage = 'auto'

Config.MaxBlips = 500

-- Admin smije teleportirati do blipa / Allow admins to teleport to a blip
Config.Teleport = true

-- Zadane vrijednosti za novi blip / Defaults for a new blip
Config.Defaults = {
    sprite = 1,
    color = 47,
    scale = 0.8,
    shortRange = true,
}

-- Slike ikona u UI-ju (%s = naziv datoteke) / Icon images in the UI (%s = file name)
Config.SpriteUrl = 'https://docs-backend.fivem.net/blips/%s'
