-- lisix-blips | server
local RESOURCE = GetCurrentResourceName()
local blips = {}        -- [id] = blip
local nextId = 1
local useSql = false
local lastAction = {}

----------------------------------------------------------------
-- storage
----------------------------------------------------------------
local function sql(method, query, params)
    local p = promise.new()
    exports.oxmysql[method](exports.oxmysql, query, params or {}, function(result) p:resolve(result) end)
    return Citizen.Await(p)
end

local function fromRow(r)
    return {
        id = r.id, name = r.name, sprite = r.sprite, color = r.color, scale = r.scale + 0.0,
        shortRange = r.short_range == 1 or r.short_range == true,
        hidden = r.hidden == 1 or r.hidden == true,
        x = r.x + 0.0, y = r.y + 0.0, z = r.z + 0.0,
        updatedAt = r.updated_at or 0, updatedBy = r.updated_by or '',
    }
end

local function saveJson()
    local list = {}
    for _, b in pairs(blips) do list[#list + 1] = b end
    table.sort(list, function(a, b) return a.id < b.id end)
    SaveResourceFile(RESOURCE, 'data/blips.json', json.encode({ nextId = nextId, blips = list }, { indent = true }), -1)
end

local function load()
    local mode = Config.Storage
    if mode == 'auto' then mode = GetResourceState('oxmysql') == 'started' and 'mysql' or 'json' end
    useSql = mode == 'mysql'

    if useSql then
        while GetResourceState('oxmysql') ~= 'started' do Wait(250) end
        sql('query', [[
            CREATE TABLE IF NOT EXISTS lisix_blips (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(64) NOT NULL,
                sprite SMALLINT UNSIGNED NOT NULL DEFAULT 1,
                color SMALLINT UNSIGNED NOT NULL DEFAULT 0,
                scale FLOAT NOT NULL DEFAULT 0.8,
                short_range TINYINT(1) NOT NULL DEFAULT 1,
                hidden TINYINT(1) NOT NULL DEFAULT 0,
                x FLOAT NOT NULL, y FLOAT NOT NULL, z FLOAT NOT NULL,
                updated_at INT UNSIGNED NOT NULL DEFAULT 0,
                updated_by VARCHAR(64) NOT NULL DEFAULT ''
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ]])
        for _, r in ipairs(sql('query', 'SELECT * FROM lisix_blips') or {}) do
            blips[r.id] = fromRow(r)
        end
    else
        local raw = LoadResourceFile(RESOURCE, 'data/blips.json')
        local ok, data = pcall(json.decode, raw or '')
        if ok and type(data) == 'table' then
            nextId = tonumber(data.nextId) or 1
            for _, b in ipairs(data.blips or {}) do
                blips[b.id] = b
                if b.id >= nextId then nextId = b.id + 1 end
            end
        end
    end
    local n = 0
    for _ in pairs(blips) do n = n + 1 end
    print(('[lisix-blips] %d blips loaded (%s)'):format(n, useSql and 'oxmysql' or 'data/blips.json'))
end

local function persist(b, isNew)
    if useSql then
        local p = { b.name, b.sprite, b.color, b.scale, b.shortRange and 1 or 0, b.hidden and 1 or 0, b.x, b.y, b.z, b.updatedAt, b.updatedBy }
        if isNew then
            b.id = sql('insert', 'INSERT INTO lisix_blips (name, sprite, color, scale, short_range, hidden, x, y, z, updated_at, updated_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', p)
        else
            p[#p + 1] = b.id
            sql('update', 'UPDATE lisix_blips SET name = ?, sprite = ?, color = ?, scale = ?, short_range = ?, hidden = ?, x = ?, y = ?, z = ?, updated_at = ?, updated_by = ? WHERE id = ?', p)
        end
    else
        if isNew then b.id = nextId; nextId = nextId + 1 end
    end
    blips[b.id] = b
    if not useSql then saveJson() end
    return b.id
end

local function remove(id)
    blips[id] = nil
    if useSql then sql('update', 'DELETE FROM lisix_blips WHERE id = ?', { id }) else saveJson() end
end

----------------------------------------------------------------
-- helpers
----------------------------------------------------------------
local function count()
    local n = 0
    for _ in pairs(blips) do n = n + 1 end
    return n
end

local function allList()
    local list = {}
    for _, b in pairs(blips) do list[#list + 1] = b end
    table.sort(list, function(a, b) return a.id < b.id end)
    return list
end

local function publicList()
    local list = {}
    for _, b in pairs(blips) do
        if not b.hidden then
            list[#list + 1] = { id = b.id, name = b.name, sprite = b.sprite, color = b.color, scale = b.scale, shortRange = b.shortRange, x = b.x, y = b.y, z = b.z }
        end
    end
    return list
end

local function broadcast() TriggerClientEvent('lisix-blips:sync', -1, publicList()) end

local ESX, QBCore
CreateThread(function()
    if GetResourceState('es_extended') == 'started' then
        local ok, obj = pcall(function() return exports['es_extended']:getSharedObject() end)
        if ok then ESX = obj end
    elseif GetResourceState('qb-core') == 'started' then
        local ok, obj = pcall(function() return exports['qb-core']:GetCoreObject() end)
        if ok then QBCore = obj end
    end
end)

local function hasPermission(src)
    if src == 0 then return true end
    if Config.Permission.Ace and IsPlayerAceAllowed(src, Config.Permission.Ace) then return true end
    local groups = Config.Permission.Groups or {}
    if ESX then
        local x = ESX.GetPlayerFromId(src)
        local g = x and x.getGroup and x.getGroup()
        for _, name in ipairs(groups) do if g == name then return true end end
    elseif QBCore then
        for _, name in ipairs(groups) do
            if QBCore.Functions.HasPermission(src, name) then return true end
        end
    end
    return false
end

local function who(src)
    if src == 0 then return 'console' end
    return GetPlayerName(src) or ('#' .. src)
end

local function clamp(v, lo, hi, def)
    v = tonumber(v)
    if not v or v ~= v then return def end
    return math.max(lo, math.min(hi, v))
end

-- validates input; returns blip table or nil, error
local function sanitize(data, base)
    if type(data) ~= 'table' then return nil, 'invalid_name' end
    local name = tostring(data.name or ''):gsub('[%c<>]', ''):gsub('^%s+', ''):gsub('%s+$', '')
    if #name < 1 or #name > 64 then return nil, 'invalid_name' end
    local x, y, z = tonumber(data.x), tonumber(data.y), tonumber(data.z)
    if not x or not y or not z or math.abs(x) > 20000 or math.abs(y) > 20000 or math.abs(z) > 5000 then
        return nil, 'invalid_coords'
    end
    local b = base or {}
    b.name = name
    b.sprite = math.floor(clamp(data.sprite, 0, 1000, Config.Defaults.sprite))
    b.color = math.floor(clamp(data.color, 0, 85, Config.Defaults.color))
    b.scale = math.floor(clamp(data.scale, 0.3, 2.5, Config.Defaults.scale) * 100 + 0.5) / 100
    b.shortRange = data.shortRange == true
    b.hidden = data.hidden == true
    b.x, b.y, b.z = math.floor(x * 100) / 100, math.floor(y * 100) / 100, math.floor(z * 100) / 100
    return b
end

local function tooFast(src)
    local now = GetGameTimer()
    if lastAction[src] and now - lastAction[src] < 400 then return true end
    lastAction[src] = now
    return false
end

local function notify(src, msg, kind)
    if src == 0 then return print('[lisix-blips] ' .. msg) end
    TriggerClientEvent('lisix-blips:notify', src, msg, kind or 'info')
end

----------------------------------------------------------------
-- core actions (also used by exports)
----------------------------------------------------------------
local function saveBlip(data, src)
    local id = tonumber(data and data.id)
    local existing = id and blips[id]
    if id and not existing then return nil, 'not_found' end
    if not existing and count() >= Config.MaxBlips then return nil, 'limit_reached' end
    local copy = existing and json.decode(json.encode(existing)) or nil
    local b, err = sanitize(data, copy)
    if not b then return nil, err end
    b.updatedAt = os.time()
    b.updatedBy = who(src or 0)
    local newId = persist(b, not existing)
    broadcast()
    print(('[lisix-blips] %s blip #%d "%s" (%s)'):format(existing and 'updated' or 'created', newId, b.name, b.updatedBy))
    return newId, existing and 'saved' or 'created'
end

local function deleteBlip(id, src)
    local b = blips[tonumber(id) or -1]
    if not b then return false, 'not_found' end
    remove(b.id)
    broadcast()
    print(('[lisix-blips] deleted blip #%d "%s" (%s)'):format(b.id, b.name, who(src or 0)))
    return true, 'deleted', b.name
end

----------------------------------------------------------------
-- events
----------------------------------------------------------------
local function respond(src, reqId, ok, msg)
    TriggerClientEvent('lisix-blips:result', src, reqId, ok, msg, ok and allList() or nil, os.time())
end

RegisterNetEvent('lisix-blips:request', function()
    TriggerClientEvent('lisix-blips:sync', source, publicList())
end)

RegisterNetEvent('lisix-blips:save', function(reqId, data)
    local src = source
    if not hasPermission(src) then return respond(src, reqId, false, L('no_permission')) end
    if tooFast(src) then return respond(src, reqId, false, L('too_fast')) end
    local id, key = saveBlip(data, src)
    if not id then
        return respond(src, reqId, false, key == 'limit_reached' and L(key, Config.MaxBlips) or L(key))
    end
    respond(src, reqId, true, L(key, blips[id].name))
end)

RegisterNetEvent('lisix-blips:delete', function(reqId, id)
    local src = source
    if not hasPermission(src) then return respond(src, reqId, false, L('no_permission')) end
    if tooFast(src) then return respond(src, reqId, false, L('too_fast')) end
    local ok, key, name = deleteBlip(id, src)
    respond(src, reqId, ok, ok and L(key, name) or L(key))
end)

RegisterNetEvent('lisix-blips:list', function(reqId)
    local src = source
    if not hasPermission(src) then return respond(src, reqId, false, L('no_permission')) end
    respond(src, reqId, true, nil)
end)

RegisterCommand(Config.Command, function(src)
    if src == 0 then return print('[lisix-blips] ' .. L('command_help') .. ': in-game only.') end
    if not hasPermission(src) then return notify(src, L('no_permission'), 'error') end
    TriggerClientEvent('lisix-blips:open', src, {
        blips = allList(), now = os.time(), max = Config.MaxBlips, locale = LocaleTable(), lang = Config.Locale,
        spriteUrl = Config.SpriteUrl, defaults = Config.Defaults, teleport = Config.Teleport,
    })
end, false)

AddEventHandler('playerDropped', function() lastAction[source] = nil end)

----------------------------------------------------------------
-- exports
----------------------------------------------------------------
exports('GetBlips', function() return allList() end)
exports('AddBlip', function(data)
    if type(data) == 'table' then data.id = nil end
    return saveBlip(data, 0)
end)
exports('UpdateBlip', function(id, data)
    if type(data) ~= 'table' then return nil, 'not_found' end
    local b = blips[tonumber(id) or -1]
    if not b then return nil, 'not_found' end
    local merged = json.decode(json.encode(b))
    for k, v in pairs(data) do merged[k] = v end
    merged.id = b.id
    return saveBlip(merged, 0)
end)
exports('RemoveBlip', function(id) return deleteBlip(id, 0) end)

CreateThread(function()
    load()
    broadcast()
end)
