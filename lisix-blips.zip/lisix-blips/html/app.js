// lisix-blips | NUI
const RES = typeof GetParentResourceName === 'function' ? GetParentResourceName() : 'lisix-blips';
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const SPRITE = new Map(window.SPRITES.map(([id, file, gif]) => [id, { id, file: `radar_${file}.${gif ? 'gif' : 'png'}`, name: file.replace(/_/g, ' ') }]));
const COLOR = new Map(window.COLORS.map(([id, hex, en, hr]) => [id, { id, hex, en, hr }]));

const S = { blips: [], now: 0, nowAt: 0, max: 500, t: {}, lang: 'en', spriteUrl: '', defaults: {}, teleport: true, filter: 'all', sort: 'name', q: '' };
let editing = null;   // blip draft
let deleting = null;

// ================= utils =================
const t = (k, ...a) => { let s = S.t[k] ?? k; a.forEach((v) => { s = s.replace(/%[sd]/, v); }); return s; };
const sprite = (id) => SPRITE.get(Number(id)) || { id, file: null, name: `sprite ${id}` };
const color = (id) => COLOR.get(Number(id)) || { id, hex: '#888', en: `Colour ${id}`, hr: `Boja ${id}` };
const colorName = (id) => (S.lang === 'hr' ? color(id).hr : color(id).en);
const img = (id) => { const s = sprite(id); return s.file ? S.spriteUrl.replace('%s', s.file) : ''; };
const fmt = (n) => Number(n).toFixed(2);
const nowSec = () => S.now + Math.floor((Date.now() - S.nowAt) / 1000);

function ago(ts) {
  if (!ts) return t('ago_now');
  const d = Math.max(0, nowSec() - ts);
  if (d < 60) return t('ago_now');
  if (d < 3600) return t('ago_min', Math.floor(d / 60));
  if (d < 86400) return t('ago_hour', Math.floor(d / 3600));
  return t('ago_day', Math.floor(d / 86400));
}

async function post(name, body = {}) {
  try {
    const r = await fetch(`https://${RES}/${name}`, { method: 'POST', headers: { 'Content-Type': 'application/json; charset=UTF-8' }, body: JSON.stringify(body) });
    return await r.json();
  } catch (e) { return {}; }
}

let toastTimer;
function toast(msg, ok = true) {
  const el = $('toast');
  el.textContent = msg;
  el.className = 'show ' + (ok ? 'ok' : 'err');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (el.className = ''), 2800);
}

function applyResult(r) {
  if (r && r.blips) { S.blips = r.blips; if (r.now) { S.now = r.now; S.nowAt = Date.now(); } }
  if (r && r.msg) toast(r.msg, r.ok);
  render();
}

function onImgError(el) { el.replaceWith(Object.assign(document.createElement('span'), { className: 'num', textContent: el.dataset.id })); }
window.onImgError = onImgError;
const iconHtml = (id) => (img(id) ? `<img src="${esc(img(id))}" data-id="${id}" onerror="onImgError(this)" loading="lazy">` : `<span class="num">${id}</span>`);

// ================= locale =================
function applyLocale() {
  document.documentElement.lang = S.lang;
  document.querySelectorAll('[data-t]').forEach((el) => (el.textContent = t(el.dataset.t)));
  document.querySelectorAll('[data-ph]').forEach((el) => (el.placeholder = t(el.dataset.ph)));
  document.querySelectorAll('[data-title]').forEach((el) => (el.title = t(el.dataset.title)));
  $('search').placeholder = t('search');
}

// ================= list =================
function visibleList() {
  const q = S.q.trim().toLowerCase().replace(/^#/, '');
  let l = S.blips.filter((b) => (S.filter === 'all' ? true : S.filter === 'hidden' ? b.hidden : !b.hidden));
  if (q) l = l.filter((b) => b.name.toLowerCase().includes(q) || String(b.id) === q || sprite(b.sprite).name.includes(q));
  const by = { name: (a, b) => a.name.localeCompare(b.name), id: (a, b) => a.id - b.id, updated: (a, b) => (b.updatedAt || 0) - (a.updatedAt || 0) }[S.sort];
  return l.sort(by);
}

const ICON = {
  send: '<svg viewBox="0 0 24 24"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4z"/></svg>',
  tp: '<svg viewBox="0 0 24 24"><path d="M12 21s7-6.2 7-12a7 7 0 0 0-14 0c0 5.8 7 12 7 12zM12 11a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"/></svg>',
  edit: '<svg viewBox="0 0 24 24"><path d="M4 20h4L19 9l-4-4L4 16zM14 6l4 4"/></svg>',
  del: '<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/></svg>',
  radio: '<svg viewBox="0 0 24 24"><path d="M12 12h.01M8.5 8.5a5 5 0 0 0 0 7M15.5 8.5a5 5 0 0 1 0 7M5.6 5.6a9 9 0 0 0 0 12.8M18.4 5.6a9 9 0 0 1 0 12.8"/></svg>',
  globe: '<svg viewBox="0 0 24 24"><path d="M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM3 12h18M12 3c2.5 3 2.5 15 0 18M12 3c-2.5 3-2.5 15 0 18"/></svg>',
  eyeoff: '<svg viewBox="0 0 24 24"><path d="M3 3l18 18M10.6 6.1A9.8 9.8 0 0 1 12 6c6 0 9.5 6 9.5 6a16 16 0 0 1-3 3.6M6.5 7.6A16 16 0 0 0 2.5 12S6 18 12 18a9 9 0 0 0 4-1M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>',
  pin: '<svg viewBox="0 0 24 24"><path d="M12 21s7-6.2 7-12a7 7 0 0 0-14 0c0 5.8 7 12 7 12z"/></svg>',
};

function render() {
  const all = S.blips, hidden = all.filter((b) => b.hidden).length;
  $('sTotal').textContent = all.length;
  $('sTotalSub').textContent = t('stat_total_sub', S.max);
  $('sVisible').textContent = all.length - hidden;
  $('sHidden').textContent = hidden;
  $('sShort').textContent = all.filter((b) => b.shortRange && !b.hidden).length;
  $('cAll').textContent = all.length;
  $('cVisible').textContent = all.length - hidden;
  $('cHidden').textContent = hidden;
  document.querySelectorAll('#filter button').forEach((b) => b.classList.toggle('on', b.dataset.f === S.filter));
  $('new').disabled = all.length >= S.max;

  const list = visibleList();
  if (!list.length) {
    $('rows').innerHTML = `<div class="empty"><div>${ICON.pin}<div>${esc(all.length ? t('empty_search') : t('empty'))}</div></div></div>`;
    return;
  }
  $('rows').innerHTML = list.map((b) => {
    const c = color(b.color);
    const tags = [];
    if (b.hidden) tags.push(`<span class="tag hid">${ICON.eyeoff}${esc(t('tag_hidden'))}</span>`);
    tags.push(b.shortRange ? `<span class="tag short">${ICON.radio}${esc(t('tag_short'))}</span>` : `<span class="tag">${ICON.globe}${esc(t('tag_always'))}</span>`);
    return `<div class="row ${b.hidden ? 'is-hidden' : ''}" data-id="${b.id}">
      <div class="who"><div class="ico">${iconHtml(b.sprite)}<i style="background:${c.hex}"></i></div>
        <div style="min-width:0"><b>${esc(b.name)}</b><small>#${b.id} <em>·</em> ${esc(t('updated', ago(b.updatedAt)))}</small></div></div>
      <div class="look"><div><span class="sw" style="background:${c.hex}"></span>${esc(colorName(b.color))}</div><small>#${b.sprite} ${esc(sprite(b.sprite).name)}</small></div>
      <div class="xyz"><em>X</em>${fmt(b.x)}<em>Y</em>${fmt(b.y)}<em>Z</em>${fmt(b.z)}</div>
      <div class="scale">${Number(b.scale).toFixed(2)}×</div>
      <div class="tags">${tags.join('')}</div>
      <div class="acts">
        <button data-a="waypoint" title="${esc(t('act_waypoint'))}">${ICON.send}</button>
        ${S.teleport ? `<button data-a="teleport" title="${esc(t('act_teleport'))}">${ICON.tp}</button>` : ''}
        <button data-a="edit" title="${esc(t('act_edit'))}">${ICON.edit}</button>
        <button data-a="delete" class="del" title="${esc(t('act_delete'))}">${ICON.del}</button>
      </div></div>`;
  }).join('');
}

$('rows').addEventListener('click', (e) => {
  const btn = e.target.closest('button[data-a]');
  const row = e.target.closest('.row');
  if (!row) return;
  const b = S.blips.find((x) => x.id === Number(row.dataset.id));
  if (!b) return;
  const a = btn ? btn.dataset.a : 'edit';
  if (a === 'waypoint') { post('waypoint', { x: b.x, y: b.y }); toast(t('act_waypoint') + ' · ' + b.name); }
  else if (a === 'teleport') post('teleport', { x: b.x, y: b.y, z: b.z });
  else if (a === 'edit') openEditor(b);
  else if (a === 'delete') askDelete(b);
});

// ================= toolbar =================
$('search').addEventListener('input', (e) => { S.q = e.target.value; render(); });
$('filter').addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) { S.filter = b.dataset.f; render(); } });
$('sort').addEventListener('change', (e) => { S.sort = e.target.value; render(); });
$('new').addEventListener('click', async () => {
  const p = await post('position');
  openEditor({ id: null, name: '', sprite: S.defaults.sprite ?? 1, color: S.defaults.color ?? 47, scale: S.defaults.scale ?? 0.8, shortRange: S.defaults.shortRange ?? true, hidden: false, x: p.x ?? 0, y: p.y ?? 0, z: p.z ?? 0 });
});
$('refresh').addEventListener('click', async () => {
  $('refresh').classList.remove('spin'); void $('refresh').offsetWidth; $('refresh').classList.add('spin');
  applyResult(await post('refresh'));
});
$('close').addEventListener('click', () => post('close'));

// ================= editor =================
['ePrevImg', 'fSpriteImg'].forEach((id) => { $(id).onerror = () => ($(id).style.visibility = 'hidden'); });
function syncPreview() {
  const d = editing;
  const src = img(d.sprite);
  ['ePrevImg', 'fSpriteImg'].forEach((id) => { const el = $(id); el.style.visibility = src ? 'visible' : 'hidden'; if (src) el.src = src; });
  $('ePrevDot').style.background = color(d.color).hex;
  $('fSpriteName').textContent = sprite(d.sprite).name;
  $('fSpriteId').textContent = '#' + d.sprite;
  $('fColorName').textContent = `#${d.color} · ${colorName(d.color)}`;
  $('fScaleVal').textContent = Number(d.scale).toFixed(2) + '×';
  document.querySelectorAll('#fColors button').forEach((b) => b.classList.toggle('on', Number(b.dataset.c) === Number(d.color)));
  document.querySelectorAll('#pGrid .sp').forEach((b) => b.classList.toggle('on', Number(b.dataset.s) === Number(d.sprite)));
}

function buildColors() {
  $('fColors').innerHTML = window.COLORS.map(([id, hex]) => `<button type="button" data-c="${id}" style="background:${hex}" title="#${id} ${esc(colorName(id))}"></button>`).join('');
}
$('fColors').addEventListener('click', (e) => { const b = e.target.closest('button'); if (b) { editing.color = Number(b.dataset.c); syncPreview(); } });

function buildPicker() {
  const q = $('pSearch').value.trim().toLowerCase().replace(/^#/, '');
  const list = [...SPRITE.values()].filter((s) => !q || s.name.includes(q) || String(s.id) === q || String(s.id).startsWith(q));
  $('pGrid').innerHTML = list.map((s) => `<button type="button" class="sp" data-s="${s.id}" title="#${s.id} ${esc(s.name)}"><img src="${esc(S.spriteUrl.replace('%s', s.file))}" loading="lazy" onerror="this.style.visibility='hidden'"><span>${s.id}</span></button>`).join('');
  $('pCount').textContent = t('sprite_count', list.length);
  syncPreview();
}
$('fSpriteBtn').addEventListener('click', () => {
  const p = $('picker');
  p.classList.toggle('hidden');
  if (!p.classList.contains('hidden')) { buildPicker(); $('pSearch').focus(); const on = $('pGrid').querySelector('.on'); if (on) on.scrollIntoView({ block: 'center' }); }
});
$('pSearch').addEventListener('input', buildPicker);
$('pGrid').addEventListener('click', (e) => { const b = e.target.closest('.sp'); if (b) { editing.sprite = Number(b.dataset.s); syncPreview(); } });

$('fScale').addEventListener('input', (e) => { editing.scale = Number(e.target.value); syncPreview(); });
$('fPos').addEventListener('click', async () => {
  const p = await post('position');
  if (p.x !== undefined) { $('fX').value = fmt(p.x); $('fY').value = fmt(p.y); $('fZ').value = fmt(p.z); }
});

function openEditor(b) {
  editing = { ...b };
  $('eTitle').textContent = b.id ? t('edit_title') : t('new_title');
  $('eId').textContent = b.id ? `#${b.id}` : 'NEW';
  $('eSave').textContent = b.id ? t('save') : t('create');
  $('eDelete').classList.toggle('hidden', !b.id);
  $('fName').value = b.name;
  $('fScale').value = b.scale;
  $('fX').value = fmt(b.x); $('fY').value = fmt(b.y); $('fZ').value = fmt(b.z);
  $('fShort').checked = !!b.shortRange;
  $('fHidden').checked = !!b.hidden;
  $('picker').classList.add('hidden');
  $('pSearch').value = '';
  buildColors();
  syncPreview();
  $('editor').classList.remove('hidden');
  setTimeout(() => $('fName').focus(), 50);
}
function closeEditor() { $('editor').classList.add('hidden'); editing = null; }
$('eClose').addEventListener('click', closeEditor);
$('eCancel').addEventListener('click', closeEditor);
$('editor').addEventListener('mousedown', (e) => { if (e.target.id === 'editor') closeEditor(); });
$('eDelete').addEventListener('click', () => { const b = S.blips.find((x) => x.id === editing.id); if (b) askDelete(b); });

$('form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const d = {
    ...editing,
    name: $('fName').value.trim(),
    x: Number($('fX').value), y: Number($('fY').value), z: Number($('fZ').value),
    shortRange: $('fShort').checked, hidden: $('fHidden').checked,
  };
  if (!d.name) { $('fName').focus(); return toast(t('invalid_name'), false); }
  $('eSave').disabled = true;
  const r = await post('save', d);
  $('eSave').disabled = false;
  if (r && r.ok) closeEditor();
  applyResult(r);
});

// ================= delete =================
function askDelete(b) {
  deleting = b;
  $('cText').textContent = t('confirm_delete', b.name);
  $('confirm').classList.remove('hidden');
}
$('cNo').addEventListener('click', () => { $('confirm').classList.add('hidden'); deleting = null; });
$('cYes').addEventListener('click', async () => {
  const b = deleting;
  $('confirm').classList.add('hidden');
  deleting = null;
  if (!b) return;
  const r = await post('delete', { id: b.id });
  if (r && r.ok && editing && editing.id === b.id) closeEditor();
  applyResult(r);
});

// ================= keyboard =================
window.addEventListener('keydown', (e) => {
  if ($('app').classList.contains('hidden')) return;
  if (e.key === 'Escape') {
    if (!$('confirm').classList.contains('hidden')) { $('confirm').classList.add('hidden'); deleting = null; }
    else if (!$('picker').classList.contains('hidden') && document.activeElement === $('pSearch')) $('picker').classList.add('hidden');
    else if (editing) closeEditor();
    else post('close');
    return;
  }
  if (e.key === '/' && !['INPUT', 'SELECT', 'TEXTAREA'].includes(document.activeElement.tagName)) { e.preventDefault(); $('search').focus(); }
});

// ================= lua =================
window.addEventListener('message', (e) => {
  const m = e.data || {};
  if (m.action === 'open') {
    const d = m.data;
    Object.assign(S, { blips: d.blips || [], now: d.now || 0, nowAt: Date.now(), max: d.max, t: d.locale || {}, lang: d.lang || 'en', spriteUrl: d.spriteUrl, defaults: d.defaults || {}, teleport: d.teleport !== false });
    applyLocale();
    closeEditor();
    $('confirm').classList.add('hidden');
    $('app').classList.remove('hidden');
    render();
  } else if (m.action === 'close') {
    $('app').classList.add('hidden');
    closeEditor();
  }
});
