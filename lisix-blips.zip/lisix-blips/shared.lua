function L(key, ...)
    local lang = Locales[Config.Locale] or Locales['en']
    local str = lang[key] or (Locales['en'] and Locales['en'][key]) or key
    if select('#', ...) > 0 then return str:format(...) end
    return str
end

function LocaleTable()
    local base, lang = Locales['en'] or {}, Locales[Config.Locale] or {}
    local t = {}
    for k, v in pairs(base) do t[k] = v end
    for k, v in pairs(lang) do t[k] = v end
    return t
end
